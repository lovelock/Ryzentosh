# ProperTree
Cross platform GUI plist editor written in python.
